/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Entities.Vehicule;
import Tools.ConnexionBDD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author amout
 */
public class CtrlVehicule {
     
    private Connection cnx;
    private PreparedStatement ps;
    private ResultSet rs;
    
    public CtrlVehicule() {
        cnx = ConnexionBDD.getCnx();
    }
    
    
    public ArrayList<Vehicule> getAllVehicule()
    {
        ArrayList<Vehicule> lesVehicules = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select * from vehicule");
            rs = ps.executeQuery();
            while(rs.next())
            {
                Vehicule vehicule = new Vehicule(rs.getString("Immatriculation"),rs.getInt("Annee"),rs.getInt("CodeCategorie"),rs.getString("Modele"), rs.getString("Marque"));
                lesVehicules.add(vehicule);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesVehicules;
    }
    
    
    public String getOneRandomAvailableVehiculeByCodeCat(int cat, String date, String heure)
    {
        ArrayList<String> immatriculations = new ArrayList<>();
        try {
            System.out.println(heure);
            ps = cnx.prepareStatement("select vehicule.Immatriculation\n" +
                                        "from vehicule \n" +
                                        "WHERE vehicule.CodeCategorie = "+cat+"\n" +
                                        "AND vehicule.Immatriculation NOT IN \n" +
                                        "(SELECT vehicule.Immatriculation\n" +
                                        " FROM vehicule\n" +
                                        " JOIN lecon on vehicule.Immatriculation = lecon.Immatriculation\n" +
                                        " WHERE lecon.Date = '"+date+"'\n" +
                                        " AND lecon.Heure = '"+heure+"');");
            rs = ps.executeQuery();
            while(rs.next())
            {
                String immatriculation = rs.getString("Immatriculation");
                immatriculations.add(immatriculation);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Collections.shuffle(immatriculations);
        return immatriculations.get(0);
    }
}
