/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Entities.Categorie;
import Tools.ConnexionBDD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author amout
 */
public class CtrlCategorie {
    
    private Connection cnx;
    private PreparedStatement ps;
    private ResultSet rs;
    
    public CtrlCategorie() {
        cnx = ConnexionBDD.getCnx();
    }
    
    
    public int getCodeCatByLib(String lib)
    {
        int codeCat = 0;
         try {
            ps = cnx.prepareStatement("select codeCategorie from categorie where categorie.Libelle = '"+ lib +"';");
            rs = ps.executeQuery();
            while(rs.next())
            {
                codeCat = rs.getInt("CodeCategorie");
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlMoniteur.class.getName()).log(Level.SEVERE, null, ex);
        }
        return codeCat;
    }        
        
        
    public String getLibByCodeCat(int code)
    {
        String lib = null;
         try {
            ps = cnx.prepareStatement("select Libelle from categorie where categorie.CodeCategorie = '"+ code +"';");
            rs = ps.executeQuery();
            while(rs.next())
            {
                lib = rs.getString("Libelle");
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlMoniteur.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lib;
    }
    
    
    public ArrayList<Categorie> getAllCategorie()
    {
        ArrayList<Categorie> lesCategories = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select CodeCategorie, Libelle, Prix from categorie");
            rs = ps.executeQuery();
            while(rs.next())
            {
                Categorie categorie = new Categorie(rs.getInt("CodeCategorie"),rs.getString("Libelle"),rs.getInt("Prix"));
                lesCategories.add(categorie);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesCategories;
    }
}
