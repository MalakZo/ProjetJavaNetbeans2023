/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;


import Entities.Lecon;
import Entities.Moniteur;
import Entities.Categorie;
import Tools.ConnexionBDD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Date;


/**
 *
 * @author amout
 */
public class CtrlLecon {
    
    private Connection cnx;
    private PreparedStatement ps;
    private ResultSet rs;
    
    public CtrlLecon() {
        cnx = ConnexionBDD.getCnx();
    }
      

    
        public ArrayList<String> getMoniteurByDiplome(String categorie)
    {
        ArrayList<String> lesMoniteurs = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select moniteur.Prenom "
                    + "from moniteur "
                    + "join licence on moniteur.CodeMoniteur = licence.CodeMoniteur "
                    + "join categorie on categorie.CodeCategorie = licence.codeCategorie "
                    + "where categorie.Libelle = '"+ categorie +"'");
            rs = ps.executeQuery();
            while(rs.next())
            {
                String moniteur = rs.getString("Prenom" );
                lesMoniteurs.add(moniteur);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlLecon.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesMoniteurs;
    }
        
        
    public ArrayList<Lecon> getAllLeconByCodeEleve(int codeEleve)
    {
        ArrayList<Lecon> lesLecons = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select lecon.Date, lecon.Heure, eleve.Prenom as PrenomEleve, moniteur.Prenom as PrenomMoniteur,  lecon.Reglee from lecon join eleve on eleve.CodeEleve = lecon.CodeEleve join moniteur on lecon.CodeMoniteur = moniteur.CodeMoniteur where lecon.CodeEleve = "+ codeEleve +" and lecon.Date > '2017-01-01';");
            rs = ps.executeQuery();
            while(rs.next())
            {
                Lecon lecon = new Lecon(rs.getString("Date"),rs.getString("Heure"),rs.getString("PrenomEleve"),rs.getString("PrenomMoniteur"),rs.getInt("Reglee"));
                lesLecons.add(lecon);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlEleve.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesLecons;
    }
    
    
    public ArrayList<Lecon> getAllLeconByCodeMoniteur(int codeMoniteur)
    {
        ArrayList<Lecon> lesLecons = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select lecon.Date, lecon.Heure, eleve.Prenom as PrenomEleve, moniteur.Prenom as PrenomMoniteur, lecon.Reglee from lecon join eleve on lecon.CodeEleve = eleve.CodeEleve join moniteur on moniteur.CodeMoniteur = lecon.CodeMoniteur where lecon.codeMoniteur = "+ codeMoniteur +" and lecon.Date > '2017-01-01';");
            rs = ps.executeQuery();
            while(rs.next())
            {
                Lecon lecon = new Lecon(rs.getString("Date"),rs.getString("Heure"),rs.getString("PrenomEleve"),rs.getString("PrenomMoniteur"),rs.getInt("Reglee"));
                lesLecons.add(lecon);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlMoniteur.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesLecons;
    }
    
    
    public ArrayList<Lecon> getAllLecon()
    {
        ArrayList<Lecon> lesLecons = new ArrayList<>();
        try {
            ps = cnx.prepareStatement("select lecon.Date, lecon.Heure, eleve.Prenom as PrenomEleve, moniteur.Prenom as PrenomMoniteur, lecon.Reglee from lecon join eleve on lecon.CodeEleve = eleve.CodeEleve join moniteur on lecon.CodeMoniteur = moniteur.CodeMoniteur where lecon.Date > '2017-01-01';");
            rs = ps.executeQuery();
            while(rs.next())
            {
                Lecon lecon = new Lecon(rs.getString("Date"),rs.getString("Heure"),rs.getString("PrenomEleve"),rs.getString("PrenomMoniteur"),rs.getInt("Reglee"));
                lesLecons.add(lecon);
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlLecon.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lesLecons;
    }
    
    public int getLastIDLecon()
    {
        int lastID = 0;
        try {
            ps = cnx.prepareStatement("select CodeLecon from lecon order by CodeLecon desc limit 1");
            rs = ps.executeQuery();
            while(rs.next())
            {
                lastID = rs.getInt("CodeLecon");
            }
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlLecon.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lastID;
    }

    
    
    public void inscrireLecon(int codeMoniteur, int codeEleve, String date, String heure, int leconID, String immatriculation)
    {
        
        try {
            System.out.println(immatriculation);
            System.out.println(codeEleve);
            System.out.println(codeMoniteur);
            System.out.println(date);
            System.out.println(heure);
            System.out.println(leconID);
            ps = cnx.prepareStatement("insert into lecon values(CodeLecon = "+leconID+",Date = '"+date+"', Heure = '"+heure+"', CodeMoniteur = "+codeMoniteur+", CodeEleve = "+codeEleve+", Immatriculation = '"+immatriculation+"', 0)");
            
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CtrlLecon.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     
     
}
